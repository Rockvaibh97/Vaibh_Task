﻿using System;

namespace Vaibh_Task.Models
{
    internal class PasswordAttribute : Attribute
    {
        public string Name { get; set; }
    }
}