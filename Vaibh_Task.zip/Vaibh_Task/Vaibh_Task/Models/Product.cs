﻿

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vaibh_Task.Models
{
    public class Product
    {    [Key]
        public int id { get; set; }

        public int categoryid { get; set; }

        public string title { get; set; }
        public string quantity { get; set; }
        public string price { get; set; }
        public string image { get; set; }

        public string discription { get; set; }




    }
}
