﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vaibh_Task.Models;

namespace Vaibh_Task.Controllers
{
    public class ProductController : Controller
    {
        [Route("Product")]
        public IActionResult Product()
        {
            return View();
        }
        [Route("Product")]
        [HttpPost]
        public IActionResult Product(Product productmodel)
        {
            if (ModelState.IsValid)
            {
                ModelState.Clear();
            }
            return View();
        }

    }
}
