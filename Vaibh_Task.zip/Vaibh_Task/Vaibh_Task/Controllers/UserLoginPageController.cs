﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vaibh_Task.Controllers
{
    public class UserLoginPageController : Controller
    {
        [Route("Login")]
        public IActionResult Login()
        {
            return View();
        }
        [Route("Login")]
        [HttpPost]
        public IActionResult Login(UserLoginPageController userloginpagemodel)
        {
            var userloginmodel = new UserLoginPageController();
            if (ModelState.IsValid)
            {
                ModelState.Clear();
            }
            return View(userloginmodel);
        }

    }
}
