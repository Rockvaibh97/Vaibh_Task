﻿using System;

namespace Vaibh_Task.Controllers
{
    internal class httpPostAttribute : Attribute
    {
    }
}