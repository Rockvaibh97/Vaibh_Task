﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vaibh_Task.Models;

namespace Vaibh_Task.Controllers
{
    public class UserController : Controller
    {
        [Route("SignUp")]
        public IActionResult SignUp()
        {
            return View();
        }
        [Route("SignUp")]
        [HttpPost]
        public IActionResult SignUp(User usermodel)
        {
            if (ModelState.IsValid)
            {
                ModelState.Clear();
            }
            return View();
        }

    }
}
